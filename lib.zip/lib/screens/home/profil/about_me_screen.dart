import 'package:flutter/material.dart';

import '../../../utils/constants.dart';

class AboutMeScreen extends StatelessWidget {
  const AboutMeScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: const Text('Tentang Saya'),
      backgroundColor: AppColors.primary,
      foregroundColor: Colors.white,
    ),
    body: const Padding(
      padding: EdgeInsets.all(24),
      child: Text(
        'Aplikasi ini dibuat sebagai proyek pembelajaran Flutter.',
        style: TextStyle(fontSize: 15, height: 1.5),
      ),
    ),
  );
}